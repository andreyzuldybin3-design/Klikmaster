package com.example.klikmaster;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(21, 24, 43);
    private static final int PANEL = Color.rgb(34, 39, 67);
    private static final int GOLD = Color.rgb(255, 202, 58);
    private static final int WHITE = Color.rgb(247, 247, 255);
    private static final int MUTED = Color.rgb(170, 176, 208);
    private static final int CYAN = Color.rgb(67, 217, 255);

    private long coins = 0;
    private int perClick = 1, autoLevel = 0;
    private long clickCost = 25, autoCost = 100;
    private TextView coinsView, rateView, clickUpgrade, autoUpgrade, statusView;
    private SharedPreferences prefs;
    private final NumberFormat number = NumberFormat.getIntegerInstance(Locale.getDefault());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("game", MODE_PRIVATE);
        load();
        build();
        refresh();
        startAuto();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackground(shape(color, 24));
        b.setPadding(16, 16, 16, 16);
        return b;
    }

    private void build() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(22, 24, 22, 18);
        page.setBackgroundColor(BG);

        TextView title = label("⭐ КЛИК-МАСТЕР ⭐", 25, GOLD, true);
        page.addView(title, new LinearLayout.LayoutParams(-1, 54));
        page.addView(label("Кликай, копи монеты и покупай улучшения!", 13, MUTED, false),
                new LinearLayout.LayoutParams(-1, 34));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setGravity(Gravity.CENTER);
        stats.setPadding(12, 14, 12, 14);
        stats.setBackground(shape(PANEL, 22));
        LinearLayout.LayoutParams statParams = new LinearLayout.LayoutParams(-1, 128);
        statParams.setMargins(0, 18, 0, 8);
        page.addView(stats, statParams);

        stats.addView(label("ТВОИ МОНЕТЫ", 12, MUTED, true));
        coinsView = label("0", 36, GOLD, true);
        stats.addView(coinsView);
        rateView = label("+1 за клик", 13, CYAN, false);
        stats.addView(rateView);

        Button click = new Button(this);
        click.setText("💰\\nКЛИКАЙ!");
        click.setTextSize(26);
        click.setTextColor(Color.rgb(52, 35, 0));
        click.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        click.setAllCaps(false);
        click.setBackground(shape(GOLD, 100));
        click.setElevation(12);
        LinearLayout.LayoutParams clickParams = new LinearLayout.LayoutParams(230, 170);
        clickParams.setMargins(0, 24, 0, 22);
        page.addView(click, clickParams);
        click.setOnClickListener(v -> {
            coins += perClick;
            refresh(); save();
            click.animate().scaleX(0.94f).scaleY(0.94f).setDuration(65)
                    .withEndAction(() -> click.animate().scaleX(1f).scaleY(1f).setDuration(85));
        });

        page.addView(label("🛒 МАГАЗИН УЛУЧШЕНИЙ", 18, WHITE, true),
                new LinearLayout.LayoutParams(-1, 42));

        clickUpgrade = button("", Color.rgb(52, 59, 102));
        LinearLayout.LayoutParams upgradeParams = new LinearLayout.LayoutParams(-1, 66);
        upgradeParams.setMargins(0, 8, 0, 5);
        page.addView(clickUpgrade, upgradeParams);
        clickUpgrade.setOnClickListener(v -> {
            if (coins >= clickCost) {
                coins -= clickCost; perClick++;
                clickCost = (long)(clickCost * 1.65);
                refresh(); save();
            } else status("Не хватает монет!");
        });

        autoUpgrade = button("", Color.rgb(52, 59, 102));
        page.addView(autoUpgrade, upgradeParams);
        autoUpgrade.setOnClickListener(v -> {
            if (coins >= autoCost) {
                coins -= autoCost; autoLevel++;
                autoCost = (long)(autoCost * 1.8);
                refresh(); save();
            } else status("Не хватает монет!");
        });

        statusView = label("Прогресс сохраняется автоматически", 12, Color.rgb(98, 230, 167), false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, 42);
        statusParams.setMargins(0, 8, 0, 0);
        page.addView(statusView, statusParams);

        Button reset = button("↻  Сбросить прогресс", Color.rgb(81, 45, 75));
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(-1, 52);
        resetParams.setMargins(0, 4, 0, 0);
        page.addView(reset, resetParams);
        reset.setOnClickListener(v -> new android.app.AlertDialog.Builder(this)
                .setTitle("Сброс игры")
                .setMessage("Точно начать заново? Весь прогресс будет удалён.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сбросить", (d, w) -> {
                    coins = 0; perClick = 1; autoLevel = 0;
                    clickCost = 25; autoCost = 100;
                    refresh(); save(); status("Новая игра началась!");
                }).show());

        setContentView(page);
    }

    private void refresh() {
        coinsView.setText(number.format(coins));
        rateView.setText("+" + perClick + " за клик  •  авто: " + autoLevel + "/сек");
        clickUpgrade.setText("⚡ Усилить клик (+1)   •   " + number.format(clickCost) + " монет");
        autoUpgrade.setText("🤖 Автокликер (+1/сек)   •   " + number.format(autoCost) + " монет");
        clickUpgrade.setEnabled(coins >= clickCost);
        autoUpgrade.setEnabled(coins >= autoCost);
        clickUpgrade.setAlpha(coins >= clickCost ? 1f : 0.55f);
        autoUpgrade.setAlpha(coins >= autoCost ? 1f : 0.55f);
    }

    private void status(String text) { statusView.setText(text); }

    private void save() {
        prefs.edit().putLong("coins", coins).putInt("perClick", perClick)
                .putInt("autoLevel", autoLevel).putLong("clickCost", clickCost)
                .putLong("autoCost", autoCost).apply();
    }

    private void load() {
        coins = prefs.getLong("coins", 0);
        perClick = prefs.getInt("perClick", 1);
        autoLevel = prefs.getInt("autoLevel", 0);
        clickCost = prefs.getLong("clickCost", 25);
        autoCost = prefs.getLong("autoCost", 100);
    }

    private void startAuto() {
        final android.os.Handler handler = new android.os.Handler();
        Runnable task = new Runnable() {
            @Override public void run() {
                if (autoLevel > 0) { coins += autoLevel; refresh(); save(); }
                handler.postDelayed(this, 1000);
            }
        };
        handler.postDelayed(task, 1000);
    }

    @Override protected void onPause() { super.onPause(); save(); }
}
